public class Arbre{
    private Noeud racine;
    
    public Arbre(Noeud racine){
        this.racine = racine;
    }
    
    public Noeud getracine(){
        return racine;
    }
}
