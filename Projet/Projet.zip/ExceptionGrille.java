public class ExceptionGrille extends Exception{
    public ExceptionGrille(String message){
        super(message);
    }
}
