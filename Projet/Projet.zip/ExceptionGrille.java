public class ExceptionGrille extends Exception{
    /**
     * @authors Youssef Oussouf et Assia El Gharbi
     * ExceptionGrille représente une exception personnalisée
     */
    
    /**
     * ExceptionGrille(String message)
     * crée une exception qui affiche le message passé en paramètre
     * @param message message à afficher 
     */
    public ExceptionGrille(String message){
        super(message);
    }
}
