public class Noeud{
    /**
     * @authors Youssef Oussouf et Assia El Gharbi
     * Noeud représente un noeud
     * ayant une information Grille
     * et un tableau de Noeud
     */
    private Grille info;
    private Noeud[] fils;
    
    /**
     * Noeud(Grille info, Noeud[] fils)
     * crée une nouvelle instance de Noeud
     * initialisée par les valeurs passées en paramètres
     * @param info information du noeud
     * @param fils tableau des fils du noeud
     */
    public Noeud(Grille info , Noeud[] fils){
        this.info = info;
        this.fils = fils;
    }
    
    /**
     * Grille getinfo()
     * méthode retournant l'info du noeud
     */
    public Grille getinfo(){
        return info;
    }
    
    /**
     * Noeud getfils(int colonne)
     * méthode retournant le fils situé à la position passée en paramètre
     * @param colonne position du fils dans le tableau
     */
    public Noeud getfils(int colonne){
        return fils[colonne];
    }
}
